// =====================================================================
//  Case inclinato da tavolo per display LCD 1.8"
//  La faccia del display resta 75 x 55 con i fori nelle stesse posizioni,
//  quindi si usa la stessa cornice della versione dritta.
//  Export:  openscad -o scatola_inclinata.stl case_lcd18_inclinato.scad
// =====================================================================

/* [Inclinazione] */
ANG   = 65;      // angolo della faccia display rispetto al piano d'appoggio
ROOF  = 45;      // pendenza del dorso posteriore (45 = stampabile senza supporti)
YMAX  = 45;      // profondita' d'appoggio

/* [Ingombro] */
L     = 75;      // larghezza
FACE  = 55;      // altezza della faccia, misurata lungo la pendenza
DEPTH = 35;      // profondita' utile, perpendicolare alla faccia
WALL  = 3;       // pareti e fondo

/* [Fissaggio cornice] */
INSET     = 5;   // distanza centro foro dai bordi della faccia
D_COL     = 8;   // diametro colonnine
D_PILOT   = 1.7; // preforo per vite M2 autofilettante
PROF_FORO = 8;
H_COL     = 10;  // sporgenza delle colonnine verso l'interno
AP_R      = 2;   // raggio angoli dell'apertura sulla faccia

/* [Apertura micro USB, sul fianco sinistro] */
USB_L = 12;
USB_H = 7;
USB_Z = 2;       // quota sopra il piano interno del fondo
USB_Y = 27.5;    // posizione lungo la profondita'

$fn = 72;

// ---------------------------------------------------------------- profilo
ca = cos(ANG);
sa = sin(ANG);
Ay = 0;             Az = DEPTH * ca;          // spigolo basso della faccia
By = Ay + FACE*ca;  Bz = Az + FACE*sa;        // spigolo alto della faccia
Zr = Bz - (YMAX - By) * tan(ROOF);           // attacco dorso / parete posteriore

module profilo2d(off = 0)
    offset(delta = off)
        polygon([[0, 0], [YMAX, 0], [YMAX, Zr], [By, Bz], [Ay, Az]]);

module prisma(w, off = 0)
    rotate([90, 0, 90])
        translate([0, 0, -w/2])
            linear_extrude(height = w) profilo2d(off);

// sistema di riferimento della faccia: x = larghezza, y = pendenza, z = normale
module su_faccia()
    translate([0, (Ay + By)/2, (Az + Bz)/2]) rotate([ANG, 0, 0]) children();

module pos_viti()
    for (sx = [-1, 1], sy = [-1, 1])
        translate([sx * (L/2 - INSET), sy * (FACE/2 - INSET), 0]) children();

// ---------------------------------------------------------------- corpo
module scatola_inclinata() {
    difference() {
        union() {
            difference() {
                prisma(L);                       // guscio esterno
                prisma(L - 2*WALL, -WALL);       // cavita' interna
                su_faccia() translate([0, 0, -WALL - 1])
                    linear_extrude(height = WALL + 2)
                        offset(r = AP_R)
                            square([L - 2*WALL - 2*AP_R, FACE - 2*WALL - 2*AP_R],
                                   center = true);
            }
            // colonnine porta-vite con rinforzo d'angolo
            su_faccia() pos_viti() translate([0, 0, -H_COL]) cylinder(d = D_COL, h = H_COL);
            su_faccia() for (sx = [-1, 1], sy = [-1, 1])
                translate([sx * (L/2 - INSET/2), sy * (FACE/2 - INSET/2), -H_COL/2])
                    cube([INSET, INSET, H_COL], center = true);
        }
        su_faccia() pos_viti() translate([0, 0, -PROF_FORO])
            cylinder(d = D_PILOT, h = PROF_FORO + 1);
        translate([-L/2 - (WALL + 4)/2, USB_Y - USB_L/2, WALL + USB_Z])
            cube([WALL + 4, USB_L, USB_H]);
    }
}

scatola_inclinata();
